To run PrintServerV1.java:

$ javac PrintServerV1.java
$ java PrintServerV1

Expected output:

[class PrintServerV1] client #2 says: I am No.0!!
[class PrintServerV1] client #2 says: I am No.1!!
[class PrintServerV1] client #2 says: I am No.2!!
[class PrintServerV1] client #2 says: I am No.3!!
[class PrintServerV1] client #2 says: I am No.4!!
[class PrintServerV1] client #2 says: I am No.5!!
[class PrintServerV1] client #2 says: I am No.6!!
[class PrintServerV1] client #2 says: I am No.7!!
[class PrintServerV1] client #2 says: I am No.8!!
[class PrintServerV1] client #3 says: I am No.0!!
[class PrintServerV1] client #3 says: I am No.1!!
[class PrintServerV1] client #3 says: I am No.2!!
[class PrintServerV1] client #3 says: I am No.3!!
[class PrintServerV1] client #3 says: I am No.4!!
[class PrintServerV1] client #3 says: I am No.5!!
[class PrintServerV1] client #3 says: I am No.6!!
[class PrintServerV1] client #3 says: I am No.7!!
[class PrintServerV1] client #3 says: I am No.8!!
[class PrintServerV1] client #2 says: I am No.9!!
[class PrintServerV1] client #2 says: I am No.10!!
[class PrintServerV1] client #2 says: I am No.11!!
[class PrintServerV1] client #2 says: I am No.12!!
[class PrintServerV1] client #2 says: I am No.13!!
[class PrintServerV1] client #2 says: I am No.14!!
[class PrintServerV1] client #2 says: I am No.15!!
[class PrintServerV1] client #2 says: I am No.16!!
[class PrintServerV1] client #2 says: I am No.17!!
[class PrintServerV1] client #3 says: I am No.9!!
[class PrintServerV1] client #2 says: I am No.18!!
[class PrintServerV1] client #2 says: I am No.19!!
[class PrintServerV1] client #2 says: I am No.20!!
[class PrintServerV1] client #2 says: I am No.21!!
[class PrintServerV1] client #2 says: I am No.22!!
[class PrintServerV1] client #2 says: I am No.23!!
[class PrintServerV1] client #3 says: I am No.10!!
[class PrintServerV1] client #3 says: I am No.11!!
[class PrintServerV1] client #3 says: I am No.12!!
[class PrintServerV1] client #3 says: I am No.13!!
[class PrintServerV1] client #3 says: I am No.14!!
[class PrintServerV1] client #3 says: I am No.15!!
[class PrintServerV1] client #3 says: I am No.16!!
[class PrintServerV1] client #3 says: I am No.17!!
[class PrintServerV1] client #3 says: I am No.18!!
[class PrintServerV1] client #3 says: I am No.19!!
[class PrintServerV1] client #3 says: I am No.20!!
[class PrintServerV1] client #2 says: I am No.24!!
[class PrintServerV1] client #2 says: I am No.25!!
[class PrintServerV1] client #2 says: I am No.26!!
[class PrintServerV1] client #2 says: I am No.27!!
[class PrintServerV1] client #2 says: I am No.28!!
[class PrintServerV1] client #2 says: I am No.29!!
[class PrintServerV1] client #2 says: I am No.30!!
[class PrintServerV1] client #2 says: I am No.31!!
[class PrintServerV1] client #2 says: I am No.32!!
[class PrintServerV1] client #3 says: I am No.21!!
[class PrintServerV1] client #3 says: I am No.22!!
[class PrintServerV1] client #2 says: I am No.33!!
[class PrintServerV1] client #3 says: I am No.23!!
[class PrintServerV1] client #3 says: I am No.24!!
[class PrintServerV1] client #3 says: I am No.25!!
[class PrintServerV1] client #2 says: I am No.34!!
[class PrintServerV1] client #2 says: I am No.35!!
[class PrintServerV1] client #2 says: I am No.36!!
[class PrintServerV1] client #2 says: I am No.37!!
[class PrintServerV1] client #2 says: I am No.38!!
[class PrintServerV1] client #3 says: I am No.26!!
[class PrintServerV1] client #3 says: I am No.27!!
[class PrintServerV1] client #3 says: I am No.28!!
[class PrintServerV1] client #3 says: I am No.29!!
[class PrintServerV1] client #3 says: I am No.30!!
[class PrintServerV1] client #3 says: I am No.31!!
[class PrintServerV1] client #3 says: I am No.32!!
[class PrintServerV1] client #3 says: I am No.33!!
[class PrintServerV1] client #3 says: I am No.34!!
[class PrintServerV1] client #3 says: I am No.35!!
[class PrintServerV1] client #3 says: I am No.36!!
[class PrintServerV1] client #2 says: I am No.39!!
[class PrintServerV1] client #2 says: I am No.40!!
[class PrintServerV1] client #2 says: I am No.41!!
[class PrintServerV1] client #2 says: I am No.42!!
[class PrintServerV1] client #2 says: I am No.43!!
[class PrintServerV1] client #2 says: I am No.44!!
[class PrintServerV1] client #3 says: I am No.37!!
[class PrintServerV1] client #3 says: I am No.38!!
[class PrintServerV1] client #2 says: I am No.45!!
[class PrintServerV1] client #2 says: I am No.46!!
[class PrintServerV1] client #2 says: I am No.47!!
[class PrintServerV1] client #2 says: I am No.48!!
[class PrintServerV1] client #2 says: I am No.49!!
[class PrintServerV1] client #2 says: I am No.50!!
[class PrintServerV1] client #3 says: I am No.39!!
[class PrintServerV1] client #3 says: I am No.40!!
[class PrintServerV1] client #3 says: I am No.41!!
[class PrintServerV1] client #3 says: I am No.42!!
[class PrintServerV1] client #3 says: I am No.43!!
[class PrintServerV1] client #3 says: I am No.44!!
[class PrintServerV1] client #3 says: I am No.45!!
[class PrintServerV1] client #2 says: I am No.51!!
[class PrintServerV1] client #2 says: I am No.52!!
[class PrintServerV1] client #2 says: I am No.53!!
[class PrintServerV1] client #2 says: I am No.54!!
[class PrintServerV1] client #2 says: I am No.55!!
[class PrintServerV1] client #2 says: I am No.56!!
[class PrintServerV1] client #2 says: I am No.57!!
[class PrintServerV1] client #3 says: I am No.46!!
[class PrintServerV1] client #3 says: I am No.47!!
[class PrintServerV1] client #3 says: I am No.48!!
[class PrintServerV1] client #3 says: I am No.49!!
[class PrintServerV1] client #3 says: I am No.50!!
[class PrintServerV1] client #3 says: I am No.51!!
[class PrintServerV1] client #3 says: I am No.52!!

the output will go on infinitly.




To run PrintServerV2.java:

$ javac PrintServerV2.java
$ java PrintServerV2

Expected output:
[class PrintServerV2] client #2 says: I am No.0!!
[class PrintServerV2] client #2 says: I am No.1!!
[class PrintServerV2] client #2 says: I am No.2!!
[class PrintServerV2] client #2 says: I am No.3!!
[class PrintServerV2] client #2 says: I am No.4!!
[class PrintServerV2] client #2 says: I am No.5!!
[class PrintServerV2] client #2 says: I am No.6!!
[class PrintServerV2] client #2 says: I am No.7!!
[class PrintServerV2] client #2 says: I am No.8!!
[class PrintServerV2] client #2 says: I am No.9!!
[class PrintServerV2] client #2 says: I am No.10!!
[class PrintServerV2] client #2 says: I am No.11!!
[class PrintServerV2] client #2 says: I am No.12!!
[class PrintServerV2] client #2 says: I am No.13!!
[class PrintServerV2] client #2 says: I am No.14!!
[class PrintServerV2] client #2 says: I am No.15!!
[class PrintServerV2] client #2 says: I am No.16!!
[class PrintServerV2] client #2 says: I am No.17!!
[class PrintServerV2] client #2 says: I am No.18!!
[class PrintServerV2] client #2 says: I am No.19!!
[class PrintServerV2] client #2 says: I am No.20!!
[class PrintServerV2] client #2 says: I am No.21!!
[class PrintServerV2] client #2 says: I am No.22!!
[class PrintServerV2] client #2 says: I am No.23!!
[class PrintServerV2] client #2 says: I am No.24!!
[class PrintServerV2] client #2 says: I am No.25!!
[class PrintServerV2] client #2 says: I am No.26!!
[class PrintServerV2] client #2 says: I am No.27!!
[class PrintServerV2] client #2 says: I am No.28!!
[class PrintServerV2] client #2 says: I am No.29!!
[class PrintServerV2] client #2 says: I am No.30!!
[class PrintServerV2] client #2 says: I am No.31!!
[class PrintServerV2] client #2 says: I am No.32!!
[class PrintServerV2] client #2 says: I am No.33!!
[class PrintServerV2] client #2 says: I am No.34!!
[class PrintServerV2] client #2 says: I am No.35!!
[class PrintServerV2] client #2 says: I am No.36!!
[class PrintServerV2] client #2 says: I am No.37!!
[class PrintServerV2] client #2 says: I am No.38!!
[class PrintServerV2] client #2 says: I am No.39!!
[class PrintServerV2] client #2 says: I am No.40!!
[class PrintServerV2] client #2 says: I am No.41!!
[class PrintServerV2] client #2 says: I am No.42!!
[class PrintServerV2] client #2 says: I am No.43!!
[class PrintServerV2] client #2 says: I am No.44!!
[class PrintServerV2] client #2 says: I am No.45!!
[class PrintServerV2] client #2 says: I am No.46!!
[class PrintServerV2] client #2 says: I am No.47!!
[class PrintServerV2] client #2 says: I am No.48!!
[class PrintServerV2] client #2 says: I am No.49!!
[class PrintServerV2] client #2 says: I am No.50!!
[class PrintServerV2] client #2 says: I am No.51!!
[class PrintServerV2] client #2 says: I am No.52!!
[class PrintServerV2] client #2 says: I am No.53!!

the output will go on infinitly.

NOTE: I put 0.1 seconds of sleep between each execution of manager thread, so it will be expected that the output does not fall through to extremely large numbers.




To run Time.java:

$ javac Time.java
$ java Time

Expected output:
1 2 3 4 5 
-- 5 second message
6 7 8 9 10 
-- 5 second message
11 
***** 11 second message
12 13 14 15 
-- 5 second message
16 17 18 19 20 
-- 5 second message
21 22 
***** 11 second message
23 24 25 
-- 5 second message
26 27 28 29 30 
-- 5 second message
31 32 33 
***** 11 second message
34 35 
-- 5 second message
36 37 38 39 40 
-- 5 second message
41 42 43 44 
***** 11 second message
45 
-- 5 second message
46 47 48 49 50 
-- 5 second message
51 52


NOTE: sleep time is 0.5 second instead of 1 full second.